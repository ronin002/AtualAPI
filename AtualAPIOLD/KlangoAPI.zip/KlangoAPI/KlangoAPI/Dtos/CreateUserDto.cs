﻿namespace KlangoAPI.Dtos
{
    public class CreateUserDto
    {
        public string Email { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string CompanyId { get; set;}
    }

    public class CreateUserOwnerDto
    {
        public string Email { get; set; }
        public string NameUser { get; set; }
        public string Password { get; set; }

        public string NameCompany { get; set; }

    }


}
