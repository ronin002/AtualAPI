﻿namespace KlangoAPI.Dtos
{
    public class UserRolesDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Guid OwnerId { get; set; }
        public Guid CompanyId { get; set; }
        public int LevelProcess { get; set; }
        public int LevelShapes { get; set; }
        public int LevelConnectors { get; set; }
        public int LevelOperations { get; set; }
        public int LevelFluxogram { get; set; }
        public bool UseApi { get; set; }

    }
}
