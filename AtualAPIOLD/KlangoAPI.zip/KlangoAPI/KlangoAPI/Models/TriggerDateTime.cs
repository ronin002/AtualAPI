﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KlangoAPI.Models
{
    public class TriggerDateTime
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Company")]
        public Guid CompanyId { get; set; }
        public virtual Company Company { get; set; }

        [ForeignKey("WorkFlow")]
        public Guid WorkflowId { get; set; }
        public virtual WorkFlow? WorkFlow { get; set; }

        public string? Description { get; set; }
        public bool Enabled { get; set; }
        public List<DateTimeExecution> DateExecutions { get; set; }
        public List<ExecutionException> DateExceptions { get; set; }
        public ETriggerState Status { get; set; }

    }

    public class DateTimeExecution
    {
        public DateTime NextRun { get; set; }
        public ETypeDateTrigger TypeDateTrigger { get; set; }
        public bool IgnoreWeekEnds { get; set; }

    }

    public class ExecutionException
    {
        public DateTime DateException { get; set; }
        public ETypeDateException TypeDateException { get; set; }
        public DateTime DateException2 { get; set; }
        public bool IgnoreWeekEnds { get; set; }

    }
}
