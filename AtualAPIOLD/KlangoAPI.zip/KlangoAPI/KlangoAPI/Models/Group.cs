﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KlangoAPI.Models
{
    public class Group
    {
        [Key]
        public Guid Id { get; set; }

        //[ForeignKey("Company")]
        public Guid CompanyId { get; set; }
       // public virtual Company Company { get; set; }

        public string Name { get; set; }
        public string Description { get; set; }
        //public List<WorkFlow> WorkFlows { get; set; }
        //public List<Process> Processes { get; set; }
    }
}
