﻿using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KlangoAPI.Models
{
    public class Role
    {
        [Key]
        public Guid Id { get; set; }

        public Guid CompanyId { get; set; }
        
        public string Name { get; set; }
        public ELevelAccess LevelProcess { get; set; }
        public ELevelAccess LevelShapes { get; set; }
        public ELevelAccess LevelConnectors { get; set; }
        public ELevelAccess LevelOperations { get; set; }
        public ELevelAccess LevelUsers { get; set; }
        public ELevelAccess LevelRoles { get; set; }
        public ELevelAccess LevelStations { get; set; }
        public bool UseApi { get; set; }
        //public List<User> Users { get; set; } = new List<User>();


    }
}
