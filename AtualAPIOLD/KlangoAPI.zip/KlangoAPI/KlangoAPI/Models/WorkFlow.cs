﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Drawing;
using System.Reflection.Metadata.Ecma335;

namespace KlangoAPI.Models
{
    public class WorkFlow
    {
        public Guid Id { get; set; }

        [ForeignKey("Company")]
        public Guid CompanyId { get; set; }
        public virtual Company Company { get; set; }
        public string Text { get; set; }

    }

    public class Decision
    {
        public Guid Id { get; set; }

        [ForeignKey("WorkFlow")]
        public Guid WorkFlowId { get; set; }
        public virtual WorkFlow WorkFlow { get; set; }

        public string Title { get; set; }
        public string GradientColor { get; set; }
        public ElseIf ElseIF { get; set; }
        public float Height { get; set; }
        public float Width { get; set; }
        public string Location { get; set; }
    }

    public class Activity
    {
        public Guid Id { get; set; }

        [ForeignKey("WorkFlow")]
        public Guid WorkFlowId { get; set; }
        public virtual WorkFlow WorkFlow { get; set; }

        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string Key { get; set; }
        public string Description { get; set; }
        public bool Enabled { get; set; }
        public List<GroupRows> GroupRows { get; set; }
        public float Height { get; set; }
        public float Width { get; set; }
        public string Location { get; set; }
        public string Center { get; set; }

        public ETypeActivity TypeActivity { get; set; }

        public string FileScript { get; set; }
    }

    public class GroupRows
    {
        public Guid Id { get; set; }
        public Guid ActivityId { get; set; }
        public string Text { get; set; }
        public Dictionary<string, string> Row { get; set; }

    }

    public class ArrowDiagram
    {
        public Guid Guid { get; set; }
        public string Id { get; set; }

        [ForeignKey("WorkFlow")]
        public Guid WorkFlowId { get; set; }
        public virtual WorkFlow WorkFlow { get; set; }

        public ArrowType ArrowType { get; set; }
        public string StartPoint { get; set; }
        public string LastPoint { get; set; }
        public string Points { get; set; }
        public string Origem { get; set; }
        public string OrigemGuid { get; set; }
        public string Destino { get; set; }
        public string DestinoGuid { get; set; }
        public string Value { get; set; }

    }
}
