﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;

namespace KlangoAPI.Models
{
    public class Process
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("Company")]
        public Guid CompanyId { get; set; }
        public virtual Company Company { get; set; }



        [ForeignKey("Group")]
        public Guid GroupId { get; set; }
        public virtual Group Group { get; set; }


        public string Name { get; set; }
        public string Description { get; set; }
        public int TimeStart { get; set; }
        public int TimeEnd { get; set; }
        public string ReferenceDate { get; set; }
        public int TypeStart { get; set; }
        public bool Sporadic { get; set; }
        public string Documentation { get; set; }
        public string RPA { get; set; }
        public ELevelRisc Risc { get; set; }
        public string SLA_Company { get; set; }
        public string SLA_Department { get; set; }
        public string SLA_Group { get; set; }
        public string Briefing { get; set; }
        public string Dependencies { get; set; }
        public List<Operation> Operations { get; set; }


    }
}
