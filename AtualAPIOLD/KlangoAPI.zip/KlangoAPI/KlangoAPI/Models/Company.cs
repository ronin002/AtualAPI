﻿using System.Diagnostics;
using System.Text.RegularExpressions;

namespace KlangoAPI.Models
{
    public class Company
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Guid OwnerId { get; set; }
        public string? BussinesPlan { get; set; }
        public string? BussinesPlanStatus { get; set; }
        //public IList<User> Users { get; set; }
        //public IList<Role> Roles { get; set; }
        //public IList<WorkFlow> WorkFlows { get; set; }
        //public IList<Process> Processes { get; set; }
        //public IList<Operation> Operations { get; set; }
        //public IList<Status> Status { get; set; }
        //public static Company RetornaEmpresaByNome(Company cEmpresa)
        //{

        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "RETORNA_EMPRESA_NOME");
        //    data.AddParametro("@v_id", cEmpresa.sNome);

        //    DataSet ds = data.ExecuteReaderDS("sp_edit_empresa");
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        cEmpresa.idEmpresa = row["id_Empresa"].ToString();
        //        cEmpresa.sNome = row["NomeEmpresa"].ToString();
        //        cEmpresa.sOwner = row["Dono"].ToString();
        //        cEmpresa.sStatus = row["estatus"].ToString();
        //    }

        //    return cEmpresa;
        //}

        //public static Company RetornaEmpresabyID(string sId)
        //{
        //    Company cEmpresa = new Company();
        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "RETORNA_EMPRESA_ID");
        //    data.AddParametro("@v_id", sId);

        //    DataSet ds = data.ExecuteReaderDS("sp_edit_empresa");
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        cEmpresa.idEmpresa = row["id_Empresa"].ToString();
        //        cEmpresa.sNome = row["NomeEmpresa"].ToString();
        //        cEmpresa.sOwner = row["Dono"].ToString();
        //        cEmpresa.sStatus = row["estatus"].ToString();
        //    }

        //    return cEmpresa;
        //}

        //public static Company RegistraEmpresa(Company cEmpresa)
        //{

        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "REGISTRA_EMPRESA");
        //    data.AddParametro("@v_Nome", cEmpresa.sNome);
        //    data.AddParametro("@v_Owner", cEmpresa.sOwner);

        //    DataSet ds = data.ExecuteReaderDS("sp_edit_empresa");
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        cEmpresa.idEmpresa = row["id_Empresa"].ToString();
        //    }

        //    return cEmpresa;
        //}

        //public static bool ExistCompany(string sNome)
        //{

        //    bool bRetorno = false;

        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "VERIFICA_EXISTENCIA_CIA");

        //    data.AddParametro("@v_Nome", sNome);


        //    DataSet ds = data.ExecuteReaderDS("sp_edit_empresa");

        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        bRetorno = true;
        //    }

        //    return bRetorno;
        //}



    }
}
