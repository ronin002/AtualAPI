﻿using System.Drawing;

namespace KlangoAPI.Models
{/*
    public class WorkFlow1
    {
        public string Text { get; set; }
        public List<Activity> Activities { get; set; }
        public List<Decision> Decisions { get; set; }
        public List<ArrowDiagram> Lines { get; set; }
        public bool IsChanged { get; set; } = false;


        public WorkFlow1()
        {
            Activities = new List<Activity>();
            Lines = new List<ArrowDiagram>();
            Decisions = new List<Decision>();
        }
    }

    public class Decision
    {
        public Guid Guid { get; set; }
        public string Title { get; set; }
        public string GradientColor { get; set; }
        public ElseIf ElseIF { get; set; }
        public float Height { get; set; }
        public float Width { get; set; }
        public string Location { get; set; }
        public Decision()
        {

        }
    }

    public class Activity
    {
        public Guid Guid { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public List<GroupRows> GroupRows { get; set; }
        public float Height { get; set; }
        public float Width { get; set; }
        public string Location { get; set; }
        public string Center { get; set; }
        public Activity()
        {
            GroupRows = new List<GroupRows>();
        }

        public void Copy(Activity activity)
        {
            this.Guid = activity.Guid;
            this.Title = activity.Title;
            this.SubTitle = activity.SubTitle;
            this.GroupRows = activity.GroupRows;
            this.Height = activity.Height;
            this.Width = activity.Width;
            this.Location = activity.Location;
        }
    }

    public class GroupRows
    {
        public string Text { get; set; }
        public Dictionary<string, string> Row { get; set; }
    }

    public class ArrowDiagram
    {
        public Guid Guid { get; set; }
        public string Id { get; set; }
        public ArrowType ArrowType { get; set; }
        public string StartPoint { get; set; }
        public string LastPoint { get; set; }
        public List<string> Points { get; set; }
        public string Origem { get; set; }
        public string Destino { get; set; }
        public string Value { get; set; }

        public ArrowDiagram()
        {
            Points = new List<string>();
        }
    }

    */
}
