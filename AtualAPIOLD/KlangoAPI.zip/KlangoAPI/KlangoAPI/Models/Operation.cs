﻿using System.ComponentModel.DataAnnotations.Schema;

namespace KlangoAPI.Models
{
    public class Operation
    {

        public Guid Id { get; set; }

        [ForeignKey("Company")]
        public Guid CompanyId { get; set; }
        public virtual Company Company { get; set; }


        [ForeignKey("Process")]
        public Guid ProcessId { get; set; }
        public virtual Process Process { get; set; }


        public string LastSucessTask { get; set; }
        public string ActualTask { get; set; }

        public Nullable<System.DateTime> Start { get; set; }
        public Nullable<System.DateTime> End { get; set; }
        //public Status Status { get; set; }
        public Nullable<bool> Exception { get; set; }
        public string Station { get; set; }
        public string Observations { get; set; }
        public DateTime ReferenceDate { get; set; }

        //public void fnc_seleciona_operacao_id(int iOperacao)
        //{

        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "ID_OPERACAO");
        //    data.AddParametro("@v_id_operacao", iOperacao);
        //    DataSet ds = data.ExecuteReaderDS("sp_seleciona_operacao");

        //    sub_popula_obj(ds);

        //}


        //public void fnc_busca_operacao_id_byDataRef(DateTime dDataRef)
        //{
        //    this.id_operacao = 0;
        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "DATA_REF");
        //    data.AddParametro("@v_id_operacao", this.id_operacao);
        //    data.AddParametro("@v_datareferencia", dDataRef);
        //    DataSet ds = data.ExecuteReaderDS("sp_seleciona_operacao");

        //    sub_popula_obj(ds);


        //}

        //public void fnc_busca_operacao_id_byDataRef_byProcesso(DateTime dDataRef, int idProcesso)
        //{
        //    this.id_operacao = 0;
        //    DB data = new DB();
        //    data.AddParametro("@v_acao", "DATA_REF");
        //    data.AddParametro("@v_id_processo", this.id_processo);
        //    data.AddParametro("@v_datareferencia", dDataRef);
        //    DataSet ds = data.ExecuteReaderDS("sp_seleciona_operacao");

        //    sub_popula_obj(ds);


        //}

        //private void sub_popula_obj(DataSet ds1)
        //{
        //    foreach (DataRow row in ds1.Tables[0].Rows)
        //    {
        //        this.id_operacao = (decimal)row["id_operacao"];
        //        this.workflow = row["workflow"].ToString();
        //        this.id_processo = (int)row["id_processo"];
        //        this.ult_task_efetuada_com_sucesso = row["task_ultima"].ToString();
        //        this.task_atual = row["task_atual"].ToString();
        //        this.etapa = row["etapa"].ToString();
        //        this.iniciodatahora = DateTime.Parse(row["iniciodatahora"].ToString());
        //        this.finaldatahora = (DateTime)row["finaldatahora"];
        //        //this.sucesso = (bool)row["workflow"];

        //        try
        //        {
        //            this.excessao = (bool)row["excessao"];
        //        }
        //        catch
        //        {
        //            this.excessao = false;
        //        }

        //        this.estacao = row["estacao"].ToString();
        //        this.usuario = row["usuario"].ToString();
        //        this.observacoes = row["observacoes"].ToString();
        //        this.status = (int)row["status"];
        //        this.data_ref = (DateTime)row["data_referencia"];
        //    }
        //}

    }

}
