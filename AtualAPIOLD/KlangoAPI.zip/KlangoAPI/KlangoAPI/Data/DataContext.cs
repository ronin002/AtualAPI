﻿
using Microsoft.EntityFrameworkCore;
using KlangoAPI.Models;
using System.Security.Cryptography;

namespace KlangoAPI.Data
{
    public class DataContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Company> Companies { get; set; }
        public DbSet<Process> Processes { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<RoleUser> RoleUsers { get; set; }
        public DbSet<WorkFlow> Workflows { get; set; }
        public DbSet<Operation> Operations { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

                //.UsingEntity<RoleUser>(
                //    ur => ur.HasOne(prop => prop.User).WithMany().HasForeignKey(prop => prop.userId),
                //    ur => ur.HasOne(prop => prop.Role).WithMany().HasForeignKey(prop => prop.roleId),
                //    ur =>
                //    {
                //        //ru.HasKey(prop => new { prop.userId, prop.roleId });
                //        ur.Property(prop => prop.CreationDate).HasDefaultValue("GETUTCDATE()");
                //    }
                //);

            base.OnModelCreating(modelBuilder);
            

        }

      

    }
}
