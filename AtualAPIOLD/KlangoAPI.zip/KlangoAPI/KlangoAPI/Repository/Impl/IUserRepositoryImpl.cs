﻿using KlangoAPI.Data;
using KlangoAPI.Models;
using System.Runtime.CompilerServices;

namespace KlangoAPI.Repository.Impl
{
    public class IUserRepositoryImpl : IUserRepository
    {
        private readonly DataContext _context;
        public IUserRepositoryImpl(DataContext context)
        {
            _context = context;
        }
        public User GetById(Guid id)
        {
            var user = new User();
            user = _context.Users.FirstOrDefault(x => x.Id == id);
            return user;
        }




        public User GetByEmail(string email)
        {
            return _context.Users.FirstOrDefault(x => x.Email == email);
        }

        public User Login(string email, string password)
        {
            return _context.Users.FirstOrDefault(x => x.Email == email && x.Password == password);
        }

        public bool Save(User user)
        {

            var userExists = _context.Users.Where(x => x.Email == user.Email).FirstOrDefault();
            if (userExists != null)
            {
                return false;
            }
            _context.Users.Add(user);
            _context.SaveChanges();
            return true;

        }

        public bool Update(User user)
        {

            var userExists = _context.Users.Any(x => x.Email == user.Email);
            if (!userExists)
            {
                return false;
            }
            _context.Users.Update(user);
            _context.SaveChanges();
            return true;

        }
    }
}
