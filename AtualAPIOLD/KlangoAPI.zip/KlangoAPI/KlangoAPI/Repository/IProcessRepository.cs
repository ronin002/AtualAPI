﻿using KlangoAPI.Models;

namespace KlangoAPI.Repository
{
    public interface IProcessRepository
    {
        public Process GetProcessById(Guid id, Guid userId);
    }
}
