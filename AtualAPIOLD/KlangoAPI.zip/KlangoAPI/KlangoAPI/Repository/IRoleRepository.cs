﻿
using KlangoAPI.Dtos;
using KlangoAPI.Models;

namespace KlangoAPI.Repository
{
    public interface IRoleRepository
    {
        public List<Role> GetRoleUser(Guid idUserm, Guid companyId);
        public List<Role> GetRolesCompany(Guid idCompany);
        public Role GetRoleById(Guid id);
        public bool AddRoleToUser(Role role, User user);
        public bool Save(Role role);
        public bool Remove (Role role);
    }
}
