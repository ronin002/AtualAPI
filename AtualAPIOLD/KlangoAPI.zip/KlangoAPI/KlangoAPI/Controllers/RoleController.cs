﻿using KlangoAPI.Dtos;
using KlangoAPI.Models;
using KlangoAPI.Repository;
using KlangoAPI.Utils;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Security.Principal;
using static System.Net.WebRequestMethods;
using Newtonsoft.Json;

namespace KlangoAPI.Controllers
{
    [ApiController]

    public class RolerController : BaseController
    {
        private readonly ILogger<UserController> _logger;


        public RolerController(
                                ILogger<UserController> logger,
                                ICompanyRepository companyRepository,
                                IUserRepository userRepository,
                                IRoleRepository roleRepository) : base(companyRepository,
                                                                        userRepository,
                                                                        roleRepository)
        {
            _logger = logger;
        }


        [HttpPost("api/v1/CreateRole")]
        public IActionResult CreateRole([FromBody] Role roleModel)
        {
            var erros = new List<string>();

            //var b = tokenService;

            if (roleModel == null) return BadRequest(new ErrorDto
            {
                Status = StatusCodes.Status400BadRequest,
                Error = "Err RXE7001 invalid data"
            });

            //Check if user has levelaccess to create role


            if (erros.Count > 0)
            {
                return BadRequest(new ErrorDto
                {
                    Status = StatusCodes.Status400BadRequest,
                    Errors = erros
                });
            }

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity == null)
                return BadRequest("Err RX7002 - Credential Failure");
               
            if (!TokenService.HasRole(identity, ELevelAccess.Add, roleModel.CompanyId))
                return BadRequest("Err RX7003 - Credential Level Failure");

            var bOk = _roleRepository.Save(roleModel);

            if (bOk)
            {
                return Ok(roleModel); //RedirectToPage("dashboard.cshtml");
                //return StatusCode(StatusCodes.Status201Created, user.Email);

            }
            else
            {
                //erros.Add("User already exists");
                return BadRequest("Role already exists");
            }
        }

        


    }
}
