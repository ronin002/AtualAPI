﻿using KlangoAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

using KlangoAPI.Repository;

namespace KlangoAPI.Controllers
{
    [Authorize]
    public class BaseController : Controller
    {
        protected readonly IUserRepository _userRepository;
        protected readonly ICompanyRepository _companyRepository;
        protected readonly IRoleRepository _roleRepository;


        public BaseController(ICompanyRepository companyRepository,
                                IUserRepository userRepository,
                                IRoleRepository roleRepository)
        {
            _companyRepository = companyRepository;
            _userRepository = userRepository;
            _roleRepository = roleRepository;
        }

        protected User ReadToken()
        {
            var idUser = User.Claims.Where(c => c.Type == ClaimTypes.Sid).Select(x => x.Value).FirstOrDefault();
            if (!string.IsNullOrEmpty(idUser))
            {
                var user = new User();
                user = _userRepository.GetById(Guid.Parse(idUser));
                return user;
            }
            else
            {
                return null;
            }
            throw new UnauthorizedAccessException("Token invalid");
        }
    }
}
