﻿using KlangoAPI.Dtos;
using KlangoAPI.Models;
using KlangoAPI.Repository;
using KlangoAPI.Utils;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace KlangoAPI.Controllers
{
    [ApiController]

    public class UserController : BaseController
    {
        private readonly ILogger<UserController> _logger;


        public UserController(
                                ILogger<UserController> logger,
                                ICompanyRepository companyRepository,
                                IUserRepository userRepository,
                                IRoleRepository roleRepository) : base(companyRepository,
                                                                        userRepository,
                                                                        roleRepository)
        {
            _logger = logger;
        }


        [HttpPost("api/v1/CreateOwner")]
        [AllowAnonymous]
        public IActionResult CreateUserOwner( [FromBody] CreateUserOwnerDto userCreateModel)
        {
            var erros = new List<string>();


            if (userCreateModel == null) return BadRequest(new ErrorDto
            {
                Status = StatusCodes.Status400BadRequest,
                Error = "Err DXE7001 invalid data"
            });


            var user = new User();
            user.Email = userCreateModel.Email;
            user.Name = userCreateModel.NameUser;

            user.Password = userCreateModel.Password;


            if (!UtilsSecurity.ValidMail(user.Email))
            {
                erros.Add("Err DXE7002 invalid data");
            }
            if (string.IsNullOrEmpty(user.Password) || string.IsNullOrWhiteSpace(user.Password) || user.Password.Length < 3)
            {
                erros.Add("Err DXE7003 invalid data");
            }

            Company company = new Company();
            company.Id = Guid.NewGuid();
            company.Name = userCreateModel.NameCompany;
            company.OwnerId = company.Id;
            var createCompany = _companyRepository.CreateCompany(company);

            if (!createCompany)
                erros.Add("Err DXE7003 invalid data - Company Already Exists");

            if (erros.Count > 0)
            {
                return BadRequest(new ErrorDto
                {
                    Status = StatusCodes.Status400BadRequest,
                    Errors = erros
                });
            }
            user.Id = company.Id;
            user.Name = userCreateModel.NameUser;
            user.CompanyId = user.Id;
            user.Password = UtilsSecurity.HashPassword(user.Email, user.Password);

            
            Role role = new Role();
            
            role.Name = "OWNER";
            role.Id = Guid.NewGuid();
            role.CompanyId = user.Id;
            role.LevelProcess = ELevelAccess.OWner;
            role.LevelConnectors = ELevelAccess.OWner;
            role.LevelShapes = ELevelAccess.OWner;
            role.LevelOperations = ELevelAccess.OWner;
            role.LevelStations = ELevelAccess.OWner;
            role.LevelUsers = ELevelAccess.OWner;
            role.LevelRoles = ELevelAccess.OWner;
            _roleRepository.Save(role);

           

            var bOk = _userRepository.Save(user);


            if (bOk)
            {

                bOk = _roleRepository.AddRoleToUser(role, user);
                //bOk = _userRepository.Update(user);
                user.Password = "";
                return Ok(user); //RedirectToPage("dashboard.cshtml");
                //return StatusCode(StatusCodes.Status201Created, user.Email);

            }
            else
            {
                //erros.Add("User already exists");
                return BadRequest("User already exists");
            }
        }


        [HttpPost("api/v1/users")]
        [AllowAnonymous]
        public IActionResult CreateUser([FromBody] CreateUserDto userCreateModel)
        {
            var erros = new List<string>();

            if (userCreateModel == null) 
                return BadRequest(new ErrorDto
                {
                    Status = StatusCodes.Status400BadRequest,
                    Error = "Err UCXE7001 invalid data"
                });


            var user = new User();
            user.Id = Guid.NewGuid();
            user.Email = userCreateModel.Email;
            user.Name = userCreateModel.Name;


            user.CompanyId = user.Id;
            user.Password = userCreateModel.Password;


            if (!UtilsSecurity.ValidMail(user.Email))
            {
                erros.Add("Err UCXE7002 invalid data");
            }
            if (string.IsNullOrEmpty(user.Password) || string.IsNullOrWhiteSpace(user.Password) || user.Password.Length < 3)
            {
                erros.Add("Err UCXE7003 invalid data");
            }

            if (erros.Count > 0)
            {
                return BadRequest(new ErrorDto
                {
                    Status = StatusCodes.Status400BadRequest,
                    Errors = erros
                });
            }

            user.Password = UtilsSecurity.HashPassword(user.Email, user.Password);

            var bOk = _userRepository.Save(user);

            if (bOk)
            {
                user.Password = "";
                return Ok(user); //RedirectToPage("dashboard.cshtml");

            }
            else
            {
                //erros.Add("User already exists");
                return BadRequest("User already exists");
            }
        }




        [HttpGet("api/v1/users/{id}")]

        public IActionResult GetUser( [FromRoute] string id)
        {
            var erros = new List<string>();

            try
            {
                var user = new User();
                user = _userRepository.GetById(Guid.Parse(id));
                return Ok(user);
            }
            catch (Exception ex)
            {

                return BadRequest(new ErrorDto
                {
                    Status = StatusCodes.Status400BadRequest,
                    Error = "Err DXG7001 Server Error"
                });
            }



        }
    }
}
