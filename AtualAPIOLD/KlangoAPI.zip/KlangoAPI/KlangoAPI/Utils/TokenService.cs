﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.Json;
using System.Text;



using KlangoAPI.Models;
using KlangoAPI.Dtos;
using Newtonsoft.Json;

namespace KlangoAPI.Utils
{
    public static class TokenService
    {

        public static string GenerateToken(User user, List<Role> roles)
        {
            var configuration = new ConfigurationBuilder().AddJsonFile($"appsettings.json");

            var config = configuration.Build();
            //var connectionString = config.GetConnectionString("ConnectionString");
            //var keyJwt = config.GetValue<string>("JwtKey");
            
            var json = JsonSerializer.Serialize(roles);
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(UtilsSecurity.JWT_KEY);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, user.Name),
                    new Claim(ClaimTypes.Email, user.Email),
                    new Claim(ClaimTypes.GroupSid, user.CompanyId.ToString()),
                    new Claim(ClaimTypes.Sid, user.Id.ToString()),
                    new Claim(ClaimTypes.Role, json)

                }),

                Expires = DateTime.UtcNow.AddHours(8),

                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public static bool HasRole(ClaimsIdentity identity, ELevelAccess levelAccess, Guid CompanyId)
        {
            //IEnumerable<Claim> claims = identity.Claims;
            // or
            //string baseClain = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/";
            string baseClain = "http://schemas.microsoft.com/ws/2008/06/identity/claims/";
            var clains = identity.Claims;
            foreach (var claim in clains)
            {
                if (claim.Type == baseClain + "sid")
                {

                }

                if (claim.Type == baseClain + "role")
                {
                    var roleClain = claim.Value;
                    if (!string.IsNullOrEmpty(roleClain))
                    {

                        List<Role> roles = new List<Role>();
                        try
                        {
                            roles = JsonConvert.DeserializeObject<List<Role>>(roleClain);
                        }
                        catch (Exception)
                        {
                            roles = null;
                            //throw;
                        }

                        if (roles != null)
                        {
                            foreach (Role role in roles)
                            {
                                if (role.LevelRoles >= levelAccess)
                                    return true;
                            }
                        }

                        break;
                    }
                }
            }

            //var roleAccess = identity.FindFirst("sid").Value;
            //var rolesAccess = identity.FindFirst("role").Value;

            return false;
        }
    }
}
